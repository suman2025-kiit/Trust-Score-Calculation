from src.quanfraud.validators import TrustValidators
from src.quanfraud.trust_score import TrustScoreCalculator

def test_trust_score_all_true():
    v = TrustValidators(ghz_fidelity_tau=0.5, ece_tau=0.08)
    s = TrustScoreCalculator(v)
    assert s.compute(ghz_fidelity=0.9, did_ok=True, kernel_privacy_ok=True, audit_ok=True, ece=0.01) == 5

def test_trust_score_thresholds():
    v = TrustValidators(ghz_fidelity_tau=0.6, ece_tau=0.05)
    s = TrustScoreCalculator(v)
    # Fails both GHZ + ECE thresholds
    assert s.compute(ghz_fidelity=0.5, did_ok=True, kernel_privacy_ok=True, audit_ok=True, ece=0.08) == 3
