#!/usr/bin/env python3
import argparse, csv, json, os
from src.quanfraud.realtime import RealtimeSimulator
from src.quanfraud.plotting import make_dual_axis_plot

def main():
    ap = argparse.ArgumentParser(description='Simulate realtime QuanFraud stream and compute Trust Score.')
    ap.add_argument('--batches', type=int, default=12)
    ap.add_argument('--out', type=str, default='data/example_stream_log.csv')
    ap.add_argument('--json', type=str, default='data/example_stream_log.json')
    ap.add_argument('--fig', type=str, default='data/quanfraud_realtime_trust_vs_time_ba.jpg')
    args = ap.parse_args()

    sim = RealtimeSimulator()
    rows = [sim.next_batch(i) for i in range(1, args.batches+1)]

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader(); writer.writerows(rows)

    with open(args.json, 'w') as f:
        json.dump(rows, f, indent=2)

    make_dual_axis_plot(rows, args.fig)
    print('Wrote:', args.out, args.json, args.fig)

if __name__ == '__main__':
    main()
