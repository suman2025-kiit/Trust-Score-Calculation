#!/usr/bin/env python3
import argparse, csv, json
from src.quanfraud.plotting import make_dual_axis_plot

def main():
    ap = argparse.ArgumentParser(description='Make plot from a CSV or JSON log.')
    ap.add_argument('--log', type=str, required=True)
    ap.add_argument('--out', type=str, default='data/quanfraud_realtime_trust_vs_time_ba.jpg')
    args = ap.parse_args()

    rows = None
    if args.log.endswith('.csv'):
        import pandas as pd
        rows = pd.read_csv(args.log).to_dict(orient='records')
    elif args.log.endswith('.json'):
        with open(args.log) as f:
            rows = json.load(f)
    else:
        raise SystemExit('Provide a CSV or JSON file.')

    make_dual_axis_plot(rows, args.out)
    print('Wrote:', args.out)

if __name__ == '__main__':
    main()
