#!/usr/bin/env python3
import argparse, csv, json, os
from src.quanfraud.trust_score import TrustScoreCalculator
from src.quanfraud.validators import TrustValidators
from src.quanfraud.plotting import make_dual_axis_plot

def main():
    ap = argparse.ArgumentParser(description='Offline evaluation from a JSON batches file.')
    ap.add_argument('--json', type=str, required=True, help='Input JSON with batch rows.')
    ap.add_argument('--out-csv', type=str, default='data/offline_eval.csv')
    ap.add_argument('--out-fig', type=str, default='data/offline_trust_vs_time_ba.jpg')
    args = ap.parse_args()

    with open(args.json) as f:
        rows = json.load(f)

    # Recompute trust for validation (sanity check)
    val = TrustValidators(); scorer = TrustScoreCalculator(val)
    for r in rows:
        recomputed = scorer.compute(
            ghz_fidelity=r['ghz_fidelity'],
            did_ok=r['did_ok'],
            kernel_privacy_ok=r['kernel_privacy_ok'],
            audit_ok=r['audit_ok'],
            ece=r['ece']
        )
        r['trust_score_recomputed'] = int(recomputed)

    os.makedirs(os.path.dirname(args.out_csv), exist_ok=True)
    with open(args.out_csv, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader(); writer.writerows(rows)

    make_dual_axis_plot(rows, args.out_fig)
    print('Wrote:', args.out_csv, args.out_fig)

if __name__ == '__main__':
    main()
