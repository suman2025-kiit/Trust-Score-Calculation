import json, csv, math, random
from dataclasses import asdict
from datetime import datetime
import numpy as np
from .validators import TrustValidators
from .trust_score import TrustScoreCalculator

class RealtimeSimulator:
    def __init__(self, rng_seed: int = 7,
                 ghz_mu=0.62, ghz_sigma=0.07,
                 ece_mu=0.05, ece_sigma=0.02,
                 runtime_mu=22.0, runtime_sigma=1.5,
                 ba_mu=0.42, ba_sigma=0.02):
        random.seed(rng_seed); np.random.seed(rng_seed)
        self.ghz_mu, self.ghz_sigma = ghz_mu, ghz_sigma
        self.ece_mu, self.ece_sigma = ece_mu, ece_sigma
        self.runtime_mu, self.runtime_sigma = runtime_mu, runtime_sigma
        self.ba_mu, self.ba_sigma = ba_mu, ba_sigma
        self.validators = TrustValidators()
        self.scorer = TrustScoreCalculator(self.validators)

    def _clip(self, v, lo, hi): return max(lo, min(hi, v))

    def next_batch(self, batch_id: int):
        runtime = self._clip(np.random.normal(self.runtime_mu, self.runtime_sigma), 18.0, 60.0)
        ba = self._clip(np.random.normal(self.ba_mu, self.ba_sigma), 0.10, 0.95)
        ghz_fid = self._clip(np.random.normal(self.ghz_mu, self.ghz_sigma), 0.0, 1.0)
        ece = abs(np.random.normal(self.ece_mu, self.ece_sigma))

        did_ok = True
        kernel_privacy_ok = True
        audit_ok = (np.random.rand() > 0.05)

        trust = self.scorer.compute(
            ghz_fidelity=ghz_fid, did_ok=did_ok,
            kernel_privacy_ok=kernel_privacy_ok,
            audit_ok=audit_ok, ece=ece
        )

        return {
            "batch_id": batch_id,
            "timestamp_utc": datetime.utcnow().isoformat(timespec="seconds")+"Z",
            "runtime_s": round(runtime,2),
            "ba": round(ba,3),
            "ghz_fidelity": round(ghz_fid,3),
            "ghz_ok": self.validators.ghz_ok(ghz_fid),
            "did_ok": did_ok,
            "kernel_privacy_ok": kernel_privacy_ok,
            "audit_ok": audit_ok,
            "ece": round(ece,3),
            "calib_ok": self.validators.calib_ok(ece),
            "trust_score": int(trust),
        }
