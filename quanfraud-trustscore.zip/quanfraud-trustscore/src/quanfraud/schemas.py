from dataclasses import dataclass

@dataclass
class BatchMeasurement:
    batch_id: int
    runtime_s: float
    ba: float
    ghz_fidelity: float
    did_ok: bool
    kernel_privacy_ok: bool
    audit_ok: bool
    ece: float
