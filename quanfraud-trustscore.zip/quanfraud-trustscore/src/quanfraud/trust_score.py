from dataclasses import dataclass
from .validators import TrustValidators

@dataclass
class TrustScoreCalculator:
    validators: TrustValidators

    def compute(self, *, ghz_fidelity: float, did_ok: bool,
                kernel_privacy_ok: bool, audit_ok: bool, ece: float) -> int:
        score = 0
        score += int(self.validators.ghz_ok(ghz_fidelity))
        score += int(self.validators.did_ok(did_ok))
        score += int(self.validators.kernel_privacy_ok(kernel_privacy_ok))
        score += int(self.validators.audit_ok(audit_ok))
        score += int(self.validators.calib_ok(ece))
        return score
