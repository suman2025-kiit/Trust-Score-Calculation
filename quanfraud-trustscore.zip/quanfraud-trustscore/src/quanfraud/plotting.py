import matplotlib.pyplot as plt

def make_dual_axis_plot(log_rows, out_path: str):
    # Sort by time
    rows = sorted(log_rows, key=lambda r: r['runtime_s'])
    times = [r['runtime_s'] for r in rows]
    trusts = [r['trust_score'] for r in rows]
    bas = [r['ba'] for r in rows]

    plt.figure(figsize=(12,6.5))
    plt.plot(times, trusts, color='0.6', linewidth=2.2, zorder=1)

    colors = ['#009E73' if t==5 else '#E69F00' for t in trusts]
    for t,s,c in zip(times, trusts, colors):
        plt.scatter([t],[s], s=140, edgecolor='black', facecolor=c, linewidth=1.4, zorder=3)
        plt.vlines(t, 0, s, colors=c, linewidth=1.8, alpha=0.6, zorder=2)

    ax = plt.gca()
    ax.set_xlabel('Time (seconds)')
    ax.set_ylabel('Trust Score $S_{\\mathrm{trust}}$ (0–5)')
    ax.set_title('Realtime QuanFraud: Trust Score vs Time with Balanced Accuracy (Top Axis)')
    ax.set_xlim(min(times)-1, max(times)+1)
    ax.set_ylim(0,5.3)
    ax.set_xticks(sorted(set(times)))
    ax.set_yticks([0,1,2,3,4,5])
    ax.grid(True, which='both', linestyle=':', linewidth=0.9, color='0.85')

    ax_top = ax.secondary_xaxis('top')
    ax_top.set_xlim(ax.get_xlim())
    ax_top.set_xticks(times)
    ax_top.set_xticklabels([f'BA={v:.2f}' for v in bas], fontsize=10)
    ax_top.set_xlabel('Balanced Accuracy (per batch)')

    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
