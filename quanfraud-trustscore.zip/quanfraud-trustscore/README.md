# QuanFraud Trust Score (Realtime & Offline Validation)

A reference implementation to **compute, log, and validate** the QuanFraud **Trust Score** against **Time** and **Balanced Accuracy (BA)**, with publishing‑ready figures.

> **Trust Score definition (0–5)**
> 1. GHZ/θ verification pass (fidelity ≥ τ)  
> 2. DID presence & verification success  
> 3. Kernel privacy (QSVC kernel-only export)  
> 4. Audit trail receipt written  
> 5. Calibration within tolerance (ECE ≤ τ)

## Project layout

```
quanfraud-trustscore/
├── LICENSE
├── README.md
├── requirements.txt
├── src/quanfraud/
│   ├── __init__.py
│   ├── validators.py
│   ├── trust_score.py
│   ├── realtime.py
│   ├── plotting.py
│   └── schemas.py
├── scripts/
│   ├── simulate_stream.py
│   ├── eval_offline.py
│   └── make_plots.py
├── data/
│   ├── example_batches.json
│   └── example_stream_log.csv
└── tests/
    └── test_trust_score.py
```

## Installation

```bash
git clone https://github.com/<your-username>/quanfraud-trustscore.git
cd quanfraud-trustscore
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Quick start (realtime simulation)

```bash
# 1) Simulate N batches, compute Trust Score, log CSV/JSON
python scripts/simulate_stream.py --batches 12 --out data/example_stream_log.csv

# 2) Make the dual‑axis plot: Time (bottom), BA (top)
python scripts/make_plots.py --log data/example_stream_log.csv --out data/quanfraud_realtime_trust_vs_time_ba.jpg
```

## Offline evaluation (from a JSON of batches)

```bash
python scripts/eval_offline.py --json data/example_batches.json     --out-csv data/offline_eval.csv --out-fig data/offline_trust_vs_time_ba.jpg
```

## What the validators check

- **GHZ/θ verification:** Uhlmann fidelity versus threshold (τ, default 0.50).
- **DID:** presence + signature valid (stub; integrate your DID/VC verifier).
- **Kernel privacy:** forbids raw features leaving enclave; kernel-only scoring.
- **Audit trail:** on-chain receipt / append-only log success.
- **Calibration:** Expected Calibration Error (ECE) ≤ τ (default 0.08).

## Notes

- The simulation uses realistic defaults: **runtime ≈ 22 s** and **BA ≈ 0.42** for QuanFraud, with small jitter.
- Replace stubs with your live signals (GHZ fidelity, DID receipts, ECE, audit writes).

## License

MIT
