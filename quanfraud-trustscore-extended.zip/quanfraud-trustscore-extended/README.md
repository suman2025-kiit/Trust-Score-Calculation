# QuanFraud Trust Score — Extended (Adapters + CI + Packaging)

This repo packages QuanFraud **Trust Score** logic, realtime simulation, plotting and
**adapters** (IBM GHZ, Hyperledger DID, audit trail), with **pyproject** and **GitHub Actions** CI.

## Install
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -U pip
pip install -e .
```

## Realtime (with adapters)
```bash
python scripts/run_stream_live.py --config config.yaml --batches 12   --out data/live_stream.csv --json data/live_stream.json --fig data/live_trust_vs_time_ba.jpg
```

## Offline
```bash
python scripts/run_stream_live.py --batches 12    # simulate, no adapters
python scripts/make_plots.py --log data/live_stream.csv --out data/live_plot.jpg
```

## Adapters
- `src/quanfraud/adapters/ghz_ibm.py`: plug in IBM Runtime job retrieval & fidelity.
- `src/quanfraud/adapters/did_hyperledger.py`: call your Aries/Indy verifier.
- `src/quanfraud/adapters/audit_chain.py`: append tuple to ledger and return success.
- `src/quanfraud/adapters/ece.py`: compute Expected Calibration Error (ECE).

## CI (GitHub Actions)
- Lint and unit tests on Python 3.9–3.12
- Wheel/sdist build check

## Packaging
```bash
python -m build    # produces wheel & sdist in dist/
```

## Configuration
See `config.yaml` and `.env.example` for environment variables & thresholds.
