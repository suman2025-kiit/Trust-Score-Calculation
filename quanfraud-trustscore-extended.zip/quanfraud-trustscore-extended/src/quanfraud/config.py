import os, yaml
from dataclasses import dataclass

@dataclass
class AppConfig:
    ghz_threshold: float = 0.50
    ece_threshold: float = 0.08
    ba_default: float = 0.42
    runtime_target: float = 22.0

def load_config(path: str | None = None) -> AppConfig:
    cfg = AppConfig()
    p = path or os.environ.get("QUANFRAUD_CONFIG")
    if p and os.path.exists(p):
        with open(p) as f:
            data = yaml.safe_load(f) or {}
        for k,v in data.items():
            if hasattr(cfg, k): setattr(cfg, k, v)
    return cfg
