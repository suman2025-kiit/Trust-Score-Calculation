from dataclasses import dataclass

@dataclass
class TrustValidators:
    ghz_fidelity_tau: float = 0.50
    ece_tau: float = 0.08

    def ghz_ok(self, fidelity: float) -> bool:
        return fidelity >= self.ghz_fidelity_tau

    def did_ok(self, present_and_valid: bool) -> bool:
        return bool(present_and_valid)

    def kernel_privacy_ok(self, enabled: bool) -> bool:
        return bool(enabled)

    def audit_ok(self, written: bool) -> bool:
        return bool(written)

    def calib_ok(self, ece: float) -> bool:
        return ece <= self.ece_tau
