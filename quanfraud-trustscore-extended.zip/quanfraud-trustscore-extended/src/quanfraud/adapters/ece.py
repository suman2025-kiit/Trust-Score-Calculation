"""Expected Calibration Error (ECE) utility."""
import numpy as np

def expected_calibration_error(probs, labels, bins: int = 10) -> float:
    probs = np.asarray(probs)
    labels = np.asarray(labels)
    edges = np.linspace(0,1,bins+1)
    ece = 0.0
    for i in range(bins):
        lo, hi = edges[i], edges[i+1]
        mask = (probs >= lo) & (probs < hi) if i < bins-1 else (probs >= lo) & (probs <= hi)
        if not mask.any(): continue
        conf = probs[mask].mean()
        acc = (labels[mask] == (probs[mask]>=0.5)).mean()
        ece += probs[mask].size/len(probs) * abs(acc - conf)
    return float(ece)
