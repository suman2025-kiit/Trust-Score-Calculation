#!/usr/bin/env python3
import argparse, json, csv, os
from src.quanfraud import load_config
from src.quanfraud.realtime import RealtimeSimulator
from src.quanfraud.plotting import make_dual_axis_plot
from src.quanfraud.adapters.ghz_ibm import get_ghz_fidelity
from src.quanfraud.adapters.did_hyperledger import verify_did_presentation
from src.quanfraud.adapters.audit_chain import write_audit_receipt

def main():
    ap = argparse.ArgumentParser(description='Run QuanFraud stream with pluggable adapters.')
    ap.add_argument('--config', type=str, default='config.yaml')
    ap.add_argument('--batches', type=int, default=12)
    ap.add_argument('--out', type=str, default='data/live_stream.csv')
    ap.add_argument('--json', type=str, default='data/live_stream.json')
    ap.add_argument('--fig', type=str, default='data/live_trust_vs_time_ba.jpg')
    args = ap.parse_args()

    cfg = load_config(args.config)
    sim = RealtimeSimulator()

    rows = []
    for i in range(1, args.batches+1):
        row = sim.next_batch(i)
        # Optionally replace simulated GHZ with adapter value if available
        fid = get_ghz_fidelity(circuit_id=f'batch-{i}')
        if fid is not None:
            row['ghz_fidelity'] = round(float(fid),3)
        # Optionally verify DID via adapter (replace True)
        row['did_ok'] = verify_did_presentation({'batch_id':i})
        # Optionally write audit receipt
        row['audit_ok'] = write_audit_receipt({
            'Device_DID':'did:example:device123',
            't': row['timestamp_utc'],
            'F_GHZ': row['ghz_fidelity'],
            'yhat':'NA', 'H(X)':'NA'
        })
        rows.append(row)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out,'w',newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    with open(args.json,'w') as f: json.dump(rows,f,indent=2)
    make_dual_axis_plot(rows, args.fig, title='QuanFraud: Trust Score vs Time (BA on Top Axis)')
    print('Wrote:', args.out, args.json, args.fig)

if __name__ == '__main__':
    main()
