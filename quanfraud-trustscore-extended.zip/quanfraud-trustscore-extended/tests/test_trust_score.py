from quanfraud import TrustValidators, TrustScoreCalculator

def test_all_true():
    v = TrustValidators(ghz_fidelity_tau=0.5, ece_tau=0.08)
    s = TrustScoreCalculator(v)
    assert s.compute(ghz_fidelity=0.9, did_ok=True, kernel_privacy_ok=True, audit_ok=True, ece=0.02) == 5

def test_thresholds_drop():
    v = TrustValidators(ghz_fidelity_tau=0.6, ece_tau=0.05)
    s = TrustScoreCalculator(v)
    assert s.compute(ghz_fidelity=0.50, did_ok=True, kernel_privacy_ok=True, audit_ok=True, ece=0.08) == 3
